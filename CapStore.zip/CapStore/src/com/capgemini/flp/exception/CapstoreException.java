package com.capgemini.flp.exception;

import org.springframework.context.annotation.Configuration;

@Configuration
public class CapstoreException extends Exception {

	private static final long serialVersionUID = 6689124418609917554L;
	public CapstoreException(){
		   super();
		   
	   }
	   public CapstoreException(String message){
		   
		   super(message);
		   
		   
	   }
}
