package com.capgemini.flp.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.flp.bean.Capstore;
import com.capgemini.flp.exception.CapstoreException;

@Configuration
@Repository
@Transactional
public class CapstoreDaoImpl implements ICapstoreDao {
	
	

	@PersistenceContext
	private EntityManager entityManager;
	Capstore cap=new Capstore();
	
	
	@Override
	public void Encrypt(String password, String email)throws CapstoreException {
		try{
		int s = 4; 
		
	    cap.setEmail(email);
	   
		String result= new String(); 
		
		  
	        for (int i=0; i<password.length(); i++) 
	        {
	        	 char ch = (char)(((int)password.charAt(i)+s));
	        	 String ps= Character.toString(ch);
	        	 result = result.concat(ps);
	        
	        } 
	        cap.setPassword(result);
	        entityManager.persist(cap);
			
	}catch(Exception e){
	
		throw new CapstoreException(e.getMessage());
		
	}
		
	}
	@Override
	public void change(String newPwd, String oldPwd,String email)throws CapstoreException {
		try{
		
		String pass=new String();
		int s = 4;
		cap =entityManager.find(Capstore.class, email);
		
		System.out.println(oldPwd);
		System.out.println(newPwd);
		if(!(oldPwd.equals(newPwd))) {
			 for (int i=0; i<newPwd.length(); i++) 
		        {
		        	 char ch = (char)(((int)newPwd.charAt(i)+s));
		        	 String ps= Character.toString(ch);
		        	 pass = pass.concat(ps);
		       
		        } 
		        cap.setPassword(pass);
		}else{
			throw new CapstoreException();
        }
		
		entityManager.persist(cap);
		}catch(Exception e){
			throw new CapstoreException(e.getMessage());
		
		}
		
	}

	@Override
	public String forget(String email)throws CapstoreException {
		try{
		String pwd = null;
		String result=new String();
		int s = 4;
		cap =entityManager.find(Capstore.class, email);
		
		if(cap.getEmail().equals(email)){
			
			for (int i=0; i<cap.getPassword().length(); i++) 
	        {
	        	 char ch = (char)(((int)cap.getPassword().charAt(i)-s));
	        	 String ps= Character.toString(ch);
	        	 result = result.concat(ps);
	        
	        } 
			pwd = ("your password is  "+ "...... "+ result+" ......." + "  will be sent to your emailId "+email);
			return pwd;
		}else{
			throw new CapstoreException();
		}	
		}catch(Exception e){
			throw new CapstoreException(e.getMessage());
			
		}
	}
	@Override
	public boolean isValid(String pwd, String email)throws CapstoreException {
		try{
		boolean flag = false;
		cap =entityManager.find(Capstore.class, email);
		String result=new String();
		int s = 4;
		for (int i=0; i<cap.getPassword().length(); i++) 
        {
        	 char ch = (char)(((int)cap.getPassword().charAt(i)-s));
        	 String ps= Character.toString(ch);
        	 result = result.concat(ps);
     
        } 
		
		if((cap.getEmail().equals(email))&&(result.equals(pwd))){
			flag = true;
			return flag;
		}
		
		return flag;
	}catch(Exception e){
		throw new CapstoreException(e.getMessage());
		
	}

	}
}
