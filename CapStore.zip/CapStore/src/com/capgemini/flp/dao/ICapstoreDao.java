package com.capgemini.flp.dao;

import org.springframework.context.annotation.Configuration;

import com.capgemini.flp.exception.CapstoreException;

@Configuration
public interface ICapstoreDao {

	public void Encrypt(String password, String email) throws CapstoreException;
	public void change(String newPwd,String oldPwd,String email)throws CapstoreException;
	public String forget(String email)throws CapstoreException;
	public boolean isValid(String pwd,String email)throws CapstoreException;
}
