package com.capgemini.flp.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.springframework.context.annotation.Configuration;

@Configuration
@Entity
public class Capstore {

	@Id
	@Column(name="email_Id")
	private String email;
	@NotNull
	//@Pattern(regexp="[A-Za-z0-9@#&]",message="only alphabets,numbers and @ # &")
	private String password;
	@Transient
	private String passreset;
	public Capstore() {
		super();
	}
	
	

	public Capstore(String email, String password) {
		super();
		this.email = email;
		this.password = password;
		
	}



	public String getPassreset() {
		return passreset;
	}



	public void setPassreset(String passreset) {
		this.passreset = passreset;
	}



	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
}
