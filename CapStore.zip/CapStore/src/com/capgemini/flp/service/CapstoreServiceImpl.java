package com.capgemini.flp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.flp.dao.ICapstoreDao;
import com.capgemini.flp.exception.CapstoreException;

@Service
public class CapstoreServiceImpl implements ICapstoreService {

	@Autowired
	ICapstoreDao dao;
	
	@Override
	public void Encrypt(String password, String email) throws CapstoreException{
		dao.Encrypt(password, email);	
	}
	@Override
	public String forget(String email) throws CapstoreException{
		
		return dao.forget(email);
	}

	@Override
	public boolean isValid(String pwd, String email) throws CapstoreException{
		
		return dao.isValid(pwd, email);
	}
	@Override
	public void change(String newPwd, String oldPwd, String email) throws CapstoreException{
		dao.change(newPwd, oldPwd, email);
		
	}	
}
