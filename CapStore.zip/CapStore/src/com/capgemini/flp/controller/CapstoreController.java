package com.capgemini.flp.controller;
import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.flp.bean.Capstore;
import com.capgemini.flp.exception.CapstoreException;
import com.capgemini.flp.service.ICapstoreService;

@Configuration
@Controller

public class CapstoreController {

	@Autowired
	private ICapstoreService service;
	
	@RequestMapping(value="/home",method=RequestMethod.GET)
	public ModelAndView getlogin() {
		Capstore cap = new Capstore();
		return new ModelAndView ("welcome","capstore",cap);
	}

	@RequestMapping(value="/success" ,method=RequestMethod.POST)
	public ModelAndView encrypt(@PathParam(value="email")String email,@PathParam(value="password")String password)
	{String status="welcome";
		try {
			
			service.Encrypt(password, email);
			
		return new ModelAndView("success","message",status);
		
		
		}  catch (Exception e) {
			try {
				throw new CapstoreException();
			} catch (CapstoreException e1) {
				
					System.out.println("Please recheck your entries");
				
			}
		}
		return new ModelAndView("error","message",status) ;
		
	}
	
	@RequestMapping(value="/pwdchange",method=RequestMethod.GET)
	public ModelAndView getchange() {
		Capstore cap = new Capstore();
		return new ModelAndView ("change","capstore",cap);
	}
	
	@RequestMapping(value="/change" ,method=RequestMethod.POST)
	public ModelAndView change(@RequestParam(value="email")String email,@RequestParam(value="password")String oldpassword,@RequestParam(value="passreset")String newpassword)
	{
		
		String status="Password changed";
		try {
			Boolean flag =false;
			flag = service.isValid(oldpassword, email);
			System.out.println(flag);
			if(flag){
				service.change(newpassword, oldpassword, email);
			}
			return new ModelAndView("changedPwd","message",status);
		
		
		}  catch (Exception e) {
			try {
				throw new CapstoreException();
			} catch (CapstoreException e1) {
				
					System.out.println("Please recheck your entries");
				
			}
		}
		return new ModelAndView("error","message",status) ;
		
	}

	@RequestMapping(value="/forgetpwd",method=RequestMethod.GET)
	public ModelAndView getforget() {
		Capstore cap = new Capstore();
		return new ModelAndView ("forget","capstore",cap);
	}
	
	@RequestMapping(value="/forget" ,method=RequestMethod.POST)
	public ModelAndView change(@RequestParam(value="email")String email)
	{
		String status = null;
		try {
		
			status = service.forget(email);
			return new ModelAndView("passwordforget","message",status);
		
		
		}  catch (Exception e) {
			try {
				throw new CapstoreException();
			} catch (CapstoreException e1) {
				
					System.out.println("Please recheck your entries");
				
			}
		}
		return new ModelAndView("error","message",status) ;
		
	}




}
