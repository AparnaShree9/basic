package com.cg.second.form;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
public class FormPageFactory {
	WebDriver wd;
	
	@FindBy(how= How.NAME,using= "userName")
	@CacheLookup
	WebElement name;
	@FindBy(name="city")
	@CacheLookup
	WebElement city;
	@FindBy(name="password")
	@CacheLookup
	WebElement password;
	@FindBy(how= How.XPATH, using="/html/body/center/form/input[11]")
	@CacheLookup
	WebElement number;
	@FindBy(how= How.XPATH, using="/html/body/center/form/input[12]")
	@CacheLookup
	WebElement email;
	@FindBy(name="mobile")
	@CacheLookup
	WebElement contact;
	@FindBy(how=How.CSS, using="body > center >  form > input[type=\"reset\"]:nth-child(45)")
	@CacheLookup
	WebElement clear;
	@FindBy(xpath="/html/body/center/form/input[15]")
	@CacheLookup
	WebElement store;
	
	@FindBy(how= How.XPATH, using="/html/body/center/form/input[6]")
	@CacheLookup
	WebElement female;
	@FindBy(how= How.XPATH, using="/html/body/center/form/input[5]")
	@CacheLookup
	WebElement male;
	@FindBy(how= How.XPATH, using="/html/body/center/form/input[8]")
	@CacheLookup
	WebElement telgu;
	@FindBy(how= How.XPATH, using="/html/body/center/form/input[9]")
	@CacheLookup
	WebElement tamil;
	@FindBy(how= How.XPATH, using="/html/body/center/form/input[7]")
	@CacheLookup
	WebElement english;
	
	public FormPageFactory() {
		super();
	}
	
	public FormPageFactory(WebDriver driver) {
		this.wd=driver;
		PageFactory.initElements(wd,this);
	}

	public WebElement getName() {
		return name;
	}

	public void setName(String name) {
		this.name.sendKeys(name);
	}

	public WebElement getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city.sendKeys(city);
	}

	public WebElement getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);
	}

	public WebElement getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number.sendKeys(number);;
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);;
	}

	public WebElement getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact.sendKeys(contact);;
	}
	public WebElement getFemale() {
		return female;
	}

	public void setFemale() {
		female.click();
	}

	public WebElement getMale() {
		return male;
	}

	public void setMale() {
		male.click();
	}
	
	
	/*@FindBy(name="gender")
	@CacheLookup
	List<WebElement> gender;
	@FindBy(name="lang")
	@CacheLookup
	List<WebElement> language;
	public List<WebElement> getGender() {
		return gender;
	}

	public void setGender(List<WebElement> gender) {
		boolean value=gender.get(0).isSelected();
		if(value==true) {
			gender.get(0).click();
		}else {
			gender.get(1).click();
		}
	}

	public List<WebElement> getLanguage() {
		return language;
	}

	public void setLanguage(List<WebElement> language) {
		this.language = language;
	}
	*/
	
	

	
	

	public WebElement getTelgu() {
		return telgu;
	}

	public void setTelgu() {
		telgu.click();;
	}

	public WebElement getTamil() {
		return tamil;
	}

	public void setTamil() {
		tamil.click();;
	}

	public WebElement getEnglish() {
		return english;
	}

	public void setEnglish() {
		english.click();;
	}

	public WebElement getClear() {
		return clear;
	}

	
	public void setClear() {
		clear.click();
	}

	public WebElement getStore() {
		return store;
	}

	public void setStore() {
		store.click();
	}

}
