package com.cg.second.SeleniumDemo;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Demo 
{
    public static void main( String[] args )
    {
    	 System.setProperty("webdriver.chrome.driver", "C:\\Users\\apshree\\Desktop\\chromedriver.exe");
    	 WebDriver wb= new ChromeDriver();
    	/* wb.get("https://www.google.com");
    	 System.out.println(wb.getCurrentUrl()); 
    	// wb.get("https://www.flipkart.com");
    	 System.out.println(wb.getTitle());
    	 //System.out.println(wb.getPageSource());
    	 //wb.navigate().refresh();
    	 wb.manage().timeouts().implicitlyWait(5, TimeUnit.MINUTES);
    	 //wb.quit();
    	//wb.close();
    	 WebElement element = wb.findElement(By.xpath("//*[@id=\"tsf\"]/div[2]/div/div[1]/div/div[1]/input"));
    	 element.sendKeys("sql");
    	element.submit();
    	WebElement element1 = wb.findElement(By.className("LC20lb"));
    	element1.click();*/
    	 wb.get("https://www.amazon.com");
     	 WebElement element1 = wb.findElement(By.id("searchDropdownBox"));
     	 element1.click();
     	 element1.findElement(By.xpath("//*[@id=\"searchDropdownBox\"]/option[7]")).click();
     	 WebElement element2 = wb.findElement(By.xpath("//*[@id=\"twotabsearchtextbox\"]"));
     	 element2.sendKeys("laptop");
     	 element2.submit();
     	 WebElement element3 = wb.findElement(By.xpath("//*[@id=\"leftNavContainer\"]/ul[2]/div/li[2]/span/span/div/label/span/span"));
     	 element3.click();
     	 wb.navigate().refresh();
     	 WebElement element4 = wb.findElement(By.xpath("//*[@id=\"leftNavContainer\"]/ul[2]/div/li[3]/span/span/div/label/input"));
     	 element4.click();
     	 wb.navigate().refresh();
     	
     	wb.get("http://demo.guru99.com/test/radio.html");
     	 WebElement element5 = wb.findElement(By.id("vfb-7-1"));
     	element5.click();
     	wb.navigate().refresh();
     	WebElement element6 = wb.findElement(By.id("vfb-7-2"));
     	element6.click();
     	
     	
     	
    }
}
