package com.cg.second.applicationPOM;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefLogin {

	@Given("^login web page is opened$")
	public void login_web_page_is_opened() throws Throwable {
	   
	}

	@When("^wrong username is entered$")
	public void wrong_username_is_entered() throws Throwable {
	    
	}

	@Then("^Error message is printed$")
	public void error_message_is_printed() throws Throwable {
	   
	}

	@When("^wrong password is entered$")
	public void wrong_password_is_entered() throws Throwable {
	   
	}

	@When("^valid username and password is entered$")
	public void valid_username_and_password_is_entered() throws Throwable {
	   
	}

	@Then("^The form page get opened$")
	public void the_form_page_get_opened() throws Throwable {
	  
	}
}
