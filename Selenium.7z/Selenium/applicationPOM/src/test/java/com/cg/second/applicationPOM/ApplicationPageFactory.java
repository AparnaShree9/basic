package com.cg.second.applicationPOM;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class ApplicationPageFactory {

	WebDriver wd;
	WebElement fname;
	WebElement lname;
	WebElement mobile;
	WebElement gender;
	WebElement skills;
	WebElement city;
	WebElement submit;
	WebElement user;
	WebElement password;
	
}
