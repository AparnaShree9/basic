function myfunction(){
	var name =document.forms["Application"]["firstname"].value
	if(name="")

		}