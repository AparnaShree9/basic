

function myFunction() {
	
	var name= document.forms["form1"]["userName"].value;
	if(name=="") {
		alert("name field empty!!!");
		return false;
	}
	
	
	var n =	"^[A-Z][A-Za-z\\s]*$" ;
	var namen=	document.forms["form1"]["userName"].value;
		 if(!(namen.match(n))){
			 alert("Please Enter Valid name with first letter capital");
			 return false;
		 }
	





	var city= document.forms["form1"]["city"].value;
	if(city==""){
		alert("city field empty!!!");
		return false;
	}
	var c  =	"^[A-Za-z\\s]*$" ;
	var cityw= document.forms["form1"]["city"].value;
	if(!(cityw.match(c)))
        {
        alert("Please Enter Only Characters");
        
        return false;
         }
		 
		 
		 
		 
	var pass= document.forms["form1"]["password"].value;
	if(pass==""){
		alert("password needed !!!");
		return false;
	} 
    var passw= document.forms["form1"]["password"].value;
	if ((passw.length < 6) || (passw.length  > 15))
		{
			alert("password length should be between 6 and 15!!!!");
	
		}
		
		
		
		
	var num= document.forms["form1"]["number"].value;
	if(num==""){
		alert("select a number !!!");
		return false;
	} 
	
	
	
	
	
	
	var email= document.forms["form1"]["email"].value;
	if(email==""){
		alert("email is needed !!!");
		return false;
	} 
	/* var e= "[A-Za-z0-9_]+@+[a-z]+\\.com" ;
	var emailw= document.forms["form1"]["email"].value;
	if(!(emailw.match(e))){
		alert("enter valid email");
		return false;
	}  */
	
	
	
	
	
	
	
	var contact= document.forms["form1"]["mobile"].value;
	if(contact==""){
		alert("contact number is needed !!!");
		return false;
	} 
	/* var contactw= document.forms["form1"]["mobile"].value;
	if ((contactw.length < 10) || (contactw.length  > 10))
		{
			alert("contact number invalid!!!!");
			return false;
		}
		 */
	var con = "[6-9][0-9]{9}";
	var contactw= document.forms["form1"]["mobile"].value
	if(!(contactw.match(con)))	
		{
			alert("contact number invalid!!!!");
			return false;
		}
		
		
		
		
	var All=(document.forms["form1"]["mobile"].value)
			&&(document.forms["form1"]["email"].value)
			&&(document.forms["form1"]["number"].value)
			&&(document.forms["form1"]["password"].value)
			&&(document.forms["form1"]["city"].value)
			&&(document.forms["form1"]["userName"].value);
	if(All==""){
		alert("your form is empty !!!");
		return false;
	}  
	
		
		
		
		
	if(!(document.getElementById('male').checked) && !(document.getElementById('female').checked)){
		alert("Please select Gender: Male or Female");
		return false;
	}
	
	if(!(document.getElementById('eng').checked) && !(document.getElementById('tel').checked) &&
					!(document.getElementById('tam').checked)){
						alert("Select atleast one Language..");
						return false;
					}
	} 