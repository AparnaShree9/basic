function login(){
	
	var user =document.forms["Login"]["userid"].value;
	var n =	"^[A-Z][A-Za-z\\s]*$" ;
	if((user=="")||(!(user.match(n)))){
		
		 alert("Enter valid username!!!!");
			 return false;
	}
	var pass =document.forms["Login"]["password"].value;
	var n =	"^[A-Z][A-Za-z\\s]*$" ;
	if((user=="")||((pass.length < 6) || (pass.length  > 15))){
		
		 alert("Enter valid Password (6-15)!!!!");
			 return false;
	}
}