package com.cg.second.ApplicationSelenium;

import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class SeleniumApp 
{
    public static void main( String[] args )
    {
    	 System.setProperty("webdriver.chrome.driver", "C:\\Users\\apshree\\Desktop\\chromedriver.exe");
    	 WebDriver wb= new ChromeDriver();
    	 wb.get("D:\\BDD\\application.html");
    	 WebElement element = wb.findElement(By.xpath("/html/body/div/form/input[1]"));
    	 element.sendKeys("Singh");
    	 
    	 WebElement element1 = wb.findElement(By.xpath("/html/body/div/form/input[2]"));
    	 element1.sendKeys("King");
    	 
    	 WebElement element2 = wb.findElement(By.xpath("/html/body/div/form/input[3]"));
    	 element2.click();
    	 WebElement element3 = wb.findElement(By.xpath("/html/body/div/form/input[6]"));
    	 element3.click();
    	 WebElement element4 = wb.findElement(By.xpath("/html/body/div/form/input[8]"));
    	 element4.click();
    	 WebElement element5 = wb.findElement(By.xpath("/html/body/div/form/select"));
    	 element5.click();
    	 
    			 WebElement element6 = wb.findElement(By.xpath("/html/body/div/form/select/option[3]"));
    	 element6.click();
    	 WebElement element7 = wb.findElement(By.xpath(" /html/body/div/form/input[9]"));
    	 element7.click();
    	
    	 
    }
}
