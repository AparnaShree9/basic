package features;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(plugin = {"pretty","json:TestResults/HtmlResults"},glue = "com.cg.second.ApplicationSelenium")
public class RunnerTest {

}
