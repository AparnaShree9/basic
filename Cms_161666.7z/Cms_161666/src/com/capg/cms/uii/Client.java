package com.capg.cms.uii;

import java.util.Iterator;
import java.util.Scanner;
import java.util.List;
import com.capg.cms.beans.Customer;
import com.capg.cms.exception.CustomerNotFound;
import com.capg.cms.service.CustomerServiceImp;
/*@author : aparna
class: client*/

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		CustomerServiceImp service = new CustomerServiceImp();
	
        System.out.println("welcome to customer management system");
		while (true){
		System.out.println("1. add customer");
		System.out.println("2. display customer");
		System.out.println("3. display all customer");
		System.out.println("4. exit");
		Scanner sc = new Scanner(System.in);
		    int choice = sc.nextInt();
		    switch (choice) {
			case 1:
				System.out.println("Enter customer ID");
				int cid =sc.nextInt();
				System.out.println("Enter customer name");
				String cname =sc.next();
				System.out.println("Enter customer address");
				String addr =sc.next();
				Customer bean = new Customer();
				        bean.setCid(cid);
				        bean.setCname(cname);
				        bean.setAddr(addr);
				        boolean isValid =  service.validateData(bean);    
				       if(isValid){
				    	  boolean isAdded= service.addCustomer(bean);
				    	  if(isAdded){
				    		  System.out.println("record added succesfully");
				    		  System.out.println(bean);
				    		  
				    	  }
				    	  else
				    		  System.out.println("record not added");
				    	  
				       }else
				    		   System.err.println("invalid data");
				        
				break;
            case 2:
				System.out.println("enter customer id to get record..");
				int id= sc.nextInt();
				boolean valid = service.validatecid(id);
				if(valid){
					Customer c = service.displayCustomer(id);
					if(c!= null)
					System.out.println(c);
					else {
						try {
							throw new CustomerNotFound();
						} catch (CustomerNotFound e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				}
				break;
            case 3:
	            System.out.println("The list of customers:");
	             
            	service.displayAll();
            	
	            break;
             case 4:
	System.exit(0);
	            break;
			default:
				break;
			}	
		}
}}
