package com.capg.cms.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.capg.cms.beans.Customer;

public class CustomerDAOImp implements ICustomerDAO {
 static List<Customer> custList = new ArrayList<Customer>();
 
	@Override
	public boolean addCustomer(Customer c) {
		// TODO Auto-generated method stub
		boolean isAdded= false; 
		isAdded= custList.add(c);
	
		return isAdded;
	}

	@Override
	public Customer displayCustomer(int cid) {
		// TODO Auto-generated method stub
		
		Customer cust = null;
		for(Customer c: custList){
			if(c.getCid()==cid){
				cust= c;
			}
		}
		return cust;
	}

	public void displayAll(){
		Iterator<Customer> it = custList.iterator();
		while (it.hasNext()){
			Customer c =it. next();
			System.out.println(c);
		}
	}
	
	
	
	}



